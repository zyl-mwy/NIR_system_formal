function loaDingGoTop(type) {
    var ft = $('ft');
    if(ft){
        var scrolltop = $('go-top');
        var basew = parseInt(ft.clientWidth);
        var innerWidth = window.innerWidth;
        var sw = scrolltop.clientWidth;
        var kong = 12;

        if (type == 1) {
            scrolltop.style.left = 'auto';
            scrolltop.style.right = 0;
        } else if (type == 2) {
            if (innerWidth < 1920) {
                scrolltop.style.left = 'auto';
                scrolltop.style.right = 0;
            } else {
                var left = parseInt(fetchOffset(ft)['left']);
                left = left < sw ? left * 2 - sw : left;
                scrolltop.style.left = ( basew + left + kong) + 'px';
            }
        } else {
            var left = parseInt(fetchOffset(ft)['left']);
            left = left < sw ? left * 2 - sw : left;
            scrolltop.style.left = ( basew + left + kong) + 'px';
        }

    }
}