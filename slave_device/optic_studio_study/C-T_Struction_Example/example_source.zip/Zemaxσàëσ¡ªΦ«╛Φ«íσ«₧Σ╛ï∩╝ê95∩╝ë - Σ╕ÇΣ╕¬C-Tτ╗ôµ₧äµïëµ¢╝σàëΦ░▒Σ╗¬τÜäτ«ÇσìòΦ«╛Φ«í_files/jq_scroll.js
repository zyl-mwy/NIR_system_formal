/*
jQ鍚戜笂婊氩姩甯︿笂涓嬬炕椤垫寜阍?
*/
(function($){
$.fn.extend({
        Scroll:function(opt,callback){
                //鍙傛暟鍒濆鍖?
                if(!opt) var opt={};
                var _btnUp = $("#"+ opt.up);//Shawphy:鍚戜笂鎸夐挳
                var _btnDown = $("#"+ opt.down);//Shawphy:鍚戜笅鎸夐挳
                var timerID;
                var _this=this.eq(0).find("ul:first");
                var     lineH=_this.find("li:first").height(), //銮峰彇琛岄佩
                        line=opt.line?parseInt(opt.line,10):parseInt(this.height()/lineH,10), //姣忔婊氩姩镄勮鏁帮紝榛樿涓轰竴灞忥紝鍗崇埗瀹瑰櫒楂桦害
                        speed=opt.speed?parseInt(opt.speed,10):1000; //鍗峰姩阃熷害锛屾暟链艰秺澶э紝阃熷害瓒婃参锛堟绉掞级
                        timer=opt.timer //?parseInt(opt.timer,10):3000; //婊氩姩镄勬椂闂撮棿闅旓纸姣锛?
                if(line==0) line=1;
                var upHeight=0-line*lineH;
                //婊氩姩鍑芥暟
                var scrollUp=function(){
                        _btnUp.unbind("click",scrollUp); //Shawphy:鍙栨秷鍚戜笂鎸夐挳镄勫嚱鏁扮粦瀹?
                        _this.animate({
                                marginTop:upHeight
                        },speed,function(){
                                for(i=1;i<=line;i++){
                                        _this.find("li:first").appendTo(_this);
                                }
                                _this.css({marginTop:0});
                                _btnUp.bind("click",scrollUp); //Shawphy:缁戝畾鍚戜笂鎸夐挳镄勭偣鍑讳簨浠?
                        });

                }
                //Shawphy:鍚戜笅缈婚〉鍑芥暟
                var scrollDown=function(){
                        _btnDown.unbind("click",scrollDown);
                        for(i=1;i<=line;i++){
                                _this.find("li:last").show().prependTo(_this);
                        }
                        _this.css({marginTop:upHeight});
                        _this.animate({
                                marginTop:0
                        },speed,function(){
                                _btnDown.bind("click",scrollDown);
                        });
                }
               //Shawphy:镊姩鎾斁
                var autoPlay = function(){
                        if(timer)timerID = window.setInterval(scrollUp,timer);
                };
                var autoStop = function(){
                        if(timer)window.clearInterval(timerID);
                };
                 //榧犳爣浜嬩欢缁戝畾
                _this.hover(autoStop,autoPlay).mouseout();
                _btnUp.css("cursor","pointer").click( scrollUp ).hover(autoStop,autoPlay);//Shawphy:鍚戜笂鍚戜笅榧犳爣浜嬩欢缁戝畾
                _btnDown.css("cursor","pointer").click( scrollDown ).hover(autoStop,autoPlay);

        }       
})
})(jQuery);
